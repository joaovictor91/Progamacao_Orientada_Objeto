﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CamadaNegocio;
namespace CamadaApresentacao
{
    public partial class FrmCliente : Form
    {
        public FrmCliente()
        {
            InitializeComponent();
        }
		//Neste eu fiz uma função que ao selecionar alguma parte do dataGridView1 o os dados são jogados do textboxs e eu ativei 
		// e desativei o textboxs do código
        private void b_InserirC_Click(object sender, EventArgs e)
        {
            if (tb_nome_do_cliente.Text != "" && tb_endereco.Text != "" && tb_cidade.Text != "")
            {

                NCliente.Inserir(tb_nome_do_cliente.Text, tb_endereco.Text
                , tb_cidade.Text);
                MessageBox.Show("Novo Registro Realizado com Sucesso!!", "ajuda do sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //Limpar textboxs
                tb_nome_do_cliente.Clear();
                tb_endereco.Clear();
                tb_cidade.Clear();
                tb_codigoC.Clear();
                tb_codigoC.Enabled = false;
                checkBox1.Checked = false;
            }
            //Todas caixas de textos vázisa
            else if (tb_nome_do_cliente.Text == "" && tb_endereco.Text == "" && tb_cidade.Text == "")
            {
                MessageBox.Show("Favor preencher os campos");
            }
            //falta preencher dois campos
            else if (tb_nome_do_cliente.Text == "" && tb_endereco.Text == "")
            {
                MessageBox.Show("Favor preencher os campos do nome e a quantidade!!");
            }
            else if (tb_nome_do_cliente.Text == "" && tb_cidade.Text == "")
            {
                MessageBox.Show("Favor preencher os campos do nome e o preço!!");
            }
            else if (tb_endereco.Text == "" && tb_cidade.Text == "")
            {
                MessageBox.Show("Favor preencher os campos de quantidade e o preço!!");
            }
            else if (tb_endereco.Text == "" && tb_nome_do_cliente.Text == "")
            {
                MessageBox.Show("Favor preencher os campos do nome e o preço!!");
            }
            //falta preencher um campo
            else if (tb_nome_do_cliente.Text == "")
            {
                MessageBox.Show("Favor preencher o campo do nome!!");
            }
            else if (tb_endereco.Text == "")
            {
                MessageBox.Show("Favor preencher o campo do preço!!");
            }
            else if (tb_cidade.Text == "")
            {
                MessageBox.Show("Favor preencher o campo da quantidade!!");
            }

        }

        private void b_EditarC_Click(object sender, EventArgs e)
        {
            if (tb_nome_do_cliente.Text != "" && tb_endereco.Text != "" && tb_cidade.Text != "")
            {

                NCliente.Editar(Convert.ToInt32(tb_codigoC.Text), tb_nome_do_cliente.Text, tb_endereco.Text
                , tb_cidade.Text);
                MessageBox.Show("Registro Editado com Sucesso!!", "ajuda do sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //Limpar textboxs
                tb_nome_do_cliente.Clear();
                tb_endereco.Clear();
                tb_cidade.Clear();
                tb_codigoC.Clear();
                tb_codigoC.Enabled = false;
                checkBox1.Checked = false;
            }
            //Todas caixas de textos vázisa
            else if (tb_nome_do_cliente.Text == "" && tb_endereco.Text == "" && tb_cidade.Text == "")
            {
                MessageBox.Show("Favor preencher os campos");
            }
            //falta preencher dois campos
            else if (tb_nome_do_cliente.Text == "" && tb_endereco.Text == "")
            {
                MessageBox.Show("Favor preencher os campos do nome e a quantidade!!");
            }
            else if (tb_nome_do_cliente.Text == "" && tb_cidade.Text == "")
            {
                MessageBox.Show("Favor preencher os campos do nome e o preço!!");
            }
            else if (tb_endereco.Text == "" && tb_cidade.Text == "")
            {
                MessageBox.Show("Favor preencher os campos de quantidade e o preço!!");
            }
            else if (tb_endereco.Text == "" && tb_nome_do_cliente.Text == "")
            {
                MessageBox.Show("Favor preencher os campos do nome e o preço!!");
            }
            //falta preencher um campo
            else if (tb_nome_do_cliente.Text == "")
            {
                MessageBox.Show("Favor preencher o campo do nome!!");
            }
            else if (tb_endereco.Text == "")
            {
                MessageBox.Show("Favor preencher o campo do preço!!");
            }
            else if (tb_cidade.Text == "")
            {
                MessageBox.Show("Favor preencher o campo da quantidade!!");
            }
            
        }

        private void b_ExcluirC_Click(object sender, EventArgs e)
        {
            if (tb_codigoC.Text != "")
            {
                DialogResult EXCLUIR = MessageBox.Show("Deseja Realmente Excluir o Registro?",
                "EXCLUIR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (EXCLUIR == DialogResult.Yes)
                {
                    MessageBox.Show("Registro Excluido com Sucesso!!", "ajuda do sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    NCliente.Excluir(Convert.ToInt32(tb_codigoC.Text));
                    tb_codigoC.Enabled = false;
                    checkBox1.Checked = false;
                    tb_nome_do_cliente.Clear();
                    tb_endereco.Clear();
                    tb_cidade.Clear();
                    tb_codigoC.Clear();
                }
            }
            else if (tb_codigoC.Text == "" && checkBox1.Checked == false)
            {
                MessageBox.Show("Favor preencher o campo do código!!");

                MessageBox.Show("Tente ativar a caixa de texto para digitar o código!!");
            }
            else if (tb_codigoC.Text == "")
            {
                MessageBox.Show("Favor preencher o campo do código!!");
            }
        }

        private void b_ConsultarC_Click(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = NCliente.Mostrar();
            l_exibir_total.Visible = true;
            l_exibir_total.Text = "Total de registros: " + Convert.ToString(dataGridView1.Rows.Count);
            tb_codigoC.Enabled = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_codigoC.Text = Convert.ToString(dataGridView1.CurrentRow.Cells[0].Value);
            tb_nome_do_cliente.Text = Convert.ToString(dataGridView1.CurrentRow.Cells[1].Value);
            tb_endereco.Text = Convert.ToString(dataGridView1.CurrentRow.Cells[2].Value);
            tb_cidade.Text = Convert.ToString(dataGridView1.CurrentRow.Cells[3].Value);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (tb_codigoC.Enabled == false)
                tb_codigoC.Enabled = true;
            else
                tb_codigoC.Enabled = false;
        }
    }
}
